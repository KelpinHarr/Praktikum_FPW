const express = require('express');
const app = express();
const Joi = require('joi');
const cors = require('cors');
app.set("port", 3000);

app.use(express.urlencoded({extended: true}));
app.use(cors());
app.use(express.json());

app.listen(app.get("port"), function(){
    console.log(`Server started at http://localhost:${app.get("port")}`);
})

let user = [
    {
        email: "calvinharsono07@gmail.com",
        first_name: "Calvin",
        last_name: "Harsono",
        password: "123"
    }
]

app.get('/', function(req, res){
    return res.status(200).json(user);
})

app.post('/register', function(req, res){
    const email = req.body.email;
    const firstName = req.body.first_name;
    const lastName = req.body.last_name;
    const password = req.body.password;

    let isDup = false;
    for (let i = 0 ; i < user.length; i++){
        if (user[i].email == email){
            isDup = true;
        }
    }

    if (!isDup){
        const newUser = {
            "email" : email,
            "first_name" : firstName,
            "last_name" : lastName,
            "password" : password
        }
        user.push(newUser);
        return res.status(200).json(newUser);
    }
    else {
        const result = {
            "message" : "Email sudah terdaftar"
        }
        return res.status(200).json(result);
    }  
})

app.post('/login', function(req, res){
    const email = req.body.email;
    const password = req.body.password;

    for (let i = 0; i < user.length; i++){
        if (user[i].email != email){
            return res.status(200).json({"message" : "Email tidak terdaftar"});
        }
        else {
            if (user[i].password != password){
                return res.status(200).json({"message" : "Password salah"});
            }
            else {
                const result = {
                    "message" : "Login success"
                }
                return res.status(200).json(result);
            }
        }
    }
})
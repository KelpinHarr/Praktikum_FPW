import React from 'react'
import ReactDOM from 'react-dom/client'
import Home from './component/Home';
import Login from './component/Login';
import Register from './component/Register';
import Stories from './component/Stories';
import DataHandler from './component/DataHandler';
import store from "./app/store";
import { Provider } from "react-redux";

import { createBrowserRouter, RouterProvider } from "react-router-dom";
const { loadRegister } = DataHandler

const router = createBrowserRouter([
  {
    path: "/",
    element: <Home />,
    children: [
      {
        path: "/login",
        element: <Login/>
      },
      {
        path: "/register",
        element: <Register/>,
        loader: loadRegister
      },
      {
        path: "/stories",
        element: <Stories/>
      }
    ]
  }
])

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Provider store={store}>
      <RouterProvider router={router} />
    </Provider>
  </React.StrictMode>
)

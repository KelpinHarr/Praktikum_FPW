import { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { useForm } from "react-hook-form";
import Navbar from "./Navbar";

function Stories(){
    const myakun = useSelector((state)=> state.myakun.userLogin);
    const [text, setText] = useState('');
    const [errMsg, setErrMsg] = useState('');
    const [userLogin, setUserLogin] = useState([]);
    const navigate = useNavigate();

    const { register, handleSubmit, reset, formState: { errors } } = useForm();

    useEffect(() => {
    }, []);

    return(
        <>  
            <div className="flex justify-center items-center h-top">
                <div className="bg-white w-1/3 rounded-lg p-5">
                    <Navbar />
                    <p className="text-2xl text-center"><strong>Home</strong></p>                    
                </div>
            </div>
        </>
    )
}
export default Stories
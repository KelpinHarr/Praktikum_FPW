import { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { useForm } from "react-hook-form";

function Navbar(){
    const myakun = useSelector((state)=> state.myakun.userLogin);
    const [text, setText] = useState('');
    const [errMsg, setErrMsg] = useState('');
    const [userLogin, setUserLogin] = useState([]);
    const navigate = useNavigate();

    const { register, handleSubmit, reset, formState: { errors } } = useForm();

    useEffect(() => {
    }, []);

    return(
        <>
            <h6>Welcome, { myakun.email }</h6>
        </>
    )
}
export default Navbar


function Stories(){
    return(
        <>
            <h1 className="text-center">INI HALAMAN STORY</h1>
        </>
    )
}

export default Stories
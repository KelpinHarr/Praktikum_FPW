const express = require('express');
const app = express();
const Joi = require('joi');
const cors = require('cors')

app.use(express.urlencoded({extended: true}));
app.use(cors)
app.listen(3000, function(){
    console.log(`Listening to Port 3000`);
})

let user = [
    {
        email: "calvinharsono07@gmail.com",
        nama: "Calvin Harsono",
        password: "123"
    }
]

app.get('/', function(req, res){
    return res.status(200).json(user);
})

app.post('/register', function(req, res){
    const email = req.body.email;
    const nama = req.body.nama;
    const password = req.body.password;
    const confirm_password = req.body.confirm_password;

    if (!email || !nama || !password || !confirm_password){
        const result = {
            "message" : "Field tidak boleh kosong"
        }
        res.status(400).json(result);
    }
    else {
        let isDup = false;
        for (let i = 0 ; i < user.length; i++){
            if (user[i].email == email){
                isDup = true;
            }
        }

        if (isDup){
            const result = {
                "message" : "Email sudah terdaftar"
            }
            res.status(400).json(result);
        }
        else {
            if (password != confirm_password){
                const result = {
                    "message" : "Password dan confirm password tidak sama"
                }
                res.status(400).json(result);
            }
            else {
                const newUser = {
                    "email" : email,
                    "nama" : nama,
                    "password" : password
                }
                user.push(newUser);
                res.status(201).json(newUser);
            }
        }
    }
})

app.post('/login', function(req, res){
    const email = req.body.email;
    const password = req.body.password;

    if (!email || !password){
        const result = {
            "message" : "Field tidak boleh kosong"
        }
        res.status(400).json(result);
    }
    else {
        for (let i = 0; i < user.length; i++){
            if (user[i].email != email){
                return res.status(400).json({"message" : "Email tidak terdaftar"});
            }
            else {
                if (user[i].password != password){
                    return res.status(400).json({"message" : "Password salah"});
                }
                else {
                    const result = {
                        "message" : "Login success"
                    }
                    res.status(200).json(result);
                }
            }
        }
    }
})
import { Link } from "react-router-dom";
import { useState } from "react";
import axios from "axios";
import { useForm } from "react-hook-form";

function Register(){
    let [email, setEmail] = useState('');
    let [nama, setNama] = useState('');
    let [password, setPassword] = useState('');
    let [confirmPassword, setConfirmPassword] = useState('');
    let [text, setText] = useState('');

    const handleRegister = async (e) => {
        try {
            await axios.post("http://localhost:3000/register", {
                email,
                nama,
                password
            })
            setText("Register Success");
            setEmail("")
            setNama("")
            setPassword("")
            setConfirmPassword("")
        }
        catch(err){
            console.log(err);
        }
    }

    const { register, handleSubmit, reset, formState: { errors } } = useForm();

    return(
        <>
            <div className="flex justify-center items-center h-screen">
                <div className="bg-white w-1/3 rounded-lg p-5">
                    <p className="text-2xl text-center"><strong>REGISTER</strong></p>
                    <form action="">
                        <p className="text-xl text-center mt-12">Email</p>
                        <input type="text" className="w-full border border-1 border-black rounded-lg px-2 py-1 mt-3" placeholder="Email" onChange={(e) => setEmail(e.target.value)} value={email}/>

                        <p className="text-xl text-center mt-8">Nama</p>
                        <input type="text" className="w-full border border-1 border-black rounded-lg px-2 py-1 mt-3" placeholder="Nama" onChange={(e) => setNama(e.target.value)} value={nama}/>

                        <p className="text-xl text-center mt-8">Password</p>
                        <input type="text" className="w-full border border-1 border-black rounded-lg px-2 py-1 mt-3" placeholder="Password" onChange={(e) => setPassword(e.target.value)} value={password}/>

                        <p className="text-xl text-center mt-8">Confirm Password</p>
                        <input type="text" className="w-full border border-1 border-black rounded-lg px-2 py-1 mt-3" placeholder="Confirm Password" onChange={(e) => setConfirmPassword(e.target.value)} value={confirmPassword}/>

                    </form>
                    
                    <div className="flex justify-center mt-12 mb-3">
                        <button className="w-1/2 border border-1 bg-green-500 rounded-lg py-1" onClick={handleSubmit(handleRegister)}><strong>Register</strong></button>
                    </div>
                </div>
                <p className="text-xl text-center text-green-500"><strong>{text}</strong></p>
            </div>
        </>
    )
}
export default Register
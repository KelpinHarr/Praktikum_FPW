import { Link, Outlet } from "react-router-dom";

function Login(){
    return (
        <>
            <h1 className="text-4xl font-semibold">INI LOGIN</h1>
        </>
    )
}
export default Login
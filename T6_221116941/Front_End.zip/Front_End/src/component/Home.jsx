import { useState, useEffect } from "react";
import { Link, Outlet, useNavigate } from "react-router-dom";
import foto from '../assets/foto.gif'
import axios from "axios";

function Home(){
    const navigate = useNavigate();
    const [isHome, setIsHome] = useState(true);
    const [user, setUser] = useState([]);

    const handleLogin = () => {
        navigate('/login');
        setIsHome(false)
    }

    const handleRegister = () => {
        navigate('/register');
        setIsHome(false)
    }

    useEffect(() => {
        getUser()
    }, []);

    async function getUser(){
        console.log("masuk");
        const result  = await axios.get('http://localhost:3000/')
        console.log(result);
        setUser(result)
    }

    return (
        <>
            {isHome && (
                <>
                    <div className="flex justify-center items-center mt-5">
                        <img src={foto} alt="" />                
                    </div>
                    <div className="flex justify-center items-center mt-10">
                        <button className="border rounded-lg px-6 py-1 bg-green-500 ml-6 font-bold" onClick={handleLogin}>Login</button>
                        <button className="border rounded-lg px-6 py-1 bg-blue-500 ml-5 font-bold" onClick={handleRegister}>Register</button>
                        {
                            user.map((u) => {
                                return(
                                    <>
                                        <p>{u.email}</p>
                                        <p>{u.nama}</p>
                                        <p>{u.password}</p>
                                    </>
                                )
                            })
                        }
                    </div>
                </>
            )}

            <Outlet />
        </>
    )
}
export default Home